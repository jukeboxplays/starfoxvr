class Config(object):
    SQLALCHEMY_DATABASE_URI = "postgres://admin:815621@banco:5432/smaug"
    SQLALCHEMY_TRACK_MODIFICATIONS = False
