class Config(object):
    SECRET_KEY = 'SENHA-MACABRA'
